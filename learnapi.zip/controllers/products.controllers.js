require('dotenv').config();
const productShema = require('../models/product.models');

exports.addproduct = async (req, res, next) => {
    const data = req.body;
    console.log(data);

    const productdata = await productShema.create(data);

    res.json({
        msg: 'data inseted succesfuly!!',
        status: 'success',
        result: productdata
    })
}


exports.deleteProduct = async(req,res,next)=>{
    const {id} = req.params;
    console.log(id);

}