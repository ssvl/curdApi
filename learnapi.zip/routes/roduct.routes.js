const router = require('express').Router();
const {addproduct,deleteProduct} = require ('../controllers/products.controllers');


router.post('/addProduct',addproduct);
router.delete('/deleteProduct/:id',deleteProduct);

module.exports = router;